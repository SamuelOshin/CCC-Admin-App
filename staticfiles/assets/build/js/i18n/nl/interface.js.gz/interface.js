const interfaceTranslations = {
  selectedCountryAriaLabel: "Geselecteerd land",
  noCountrySelected: "Geen land geselecteerd",
  countryListAriaLabel: "Lijst met landen",
  searchPlaceholder: "Zoekopdracht",
  zeroSearchResults: "Geen resultaten gevonden",
  oneSearchResult: "1 resultaat gevonden",
  multipleSearchResults: "${count} resultaten gevonden",
  // additional countries (not supported by country-list library)
  ac: "Ascension-eiland",
  xk: "Kosovo"
};
export default interfaceTranslations;
